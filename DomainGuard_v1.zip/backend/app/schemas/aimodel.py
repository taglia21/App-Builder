"""AiModel schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class AiModelBase(BaseModel):
    model_name: str
    description: Optional[str] = None
    model_type: str
    accuracy: float = None
    version: str
    training_data: Optional[str] = None
    status: str = None

class AiModelCreate(AiModelBase):
    pass

class AiModelUpdate(BaseModel):
    model_name: str = None
    description: Optional[str] = None
    model_type: str = None
    accuracy: float = None
    version: str = None
    training_data: Optional[str] = None
    status: str = None

class AiModelInDB(AiModelBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class AiModelResponse(AiModelInDB):
    pass

class AiModelList(BaseModel):
    items: List[AiModelResponse]
    total: int
    page: int
    per_page: int
