"""Domain schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class DomainBase(BaseModel):
    name: str
    owner: str
    expiry_date: datetime.date
    registrar: str = None
    dns_provider: str = None
    ssl_status: str = None
    security_status: str = None

class DomainCreate(DomainBase):
    pass

class DomainUpdate(BaseModel):
    name: str = None
    owner: str = None
    expiry_date: datetime.date = None
    registrar: str = None
    dns_provider: str = None
    ssl_status: str = None
    security_status: str = None

class DomainInDB(DomainBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class DomainResponse(DomainInDB):
    pass

class DomainList(BaseModel):
    items: List[DomainResponse]
    total: int
    page: int
    per_page: int
