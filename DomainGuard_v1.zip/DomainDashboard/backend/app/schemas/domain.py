"""Domain schemas."""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID

class DomainBase(BaseModel):
    name: str
    registration_date: str = None
    expiration_date: str = None
    registrar: str = None
    dns_provider: str = None
    status: str = None
    ssl_status: str = None
    mx_records: Optional[str] = None
    a_records: Optional[str] = None
    cname_records: Optional[str] = None

class DomainCreate(DomainBase):
    pass

class DomainUpdate(BaseModel):
    name: str = None
    registration_date: str = None
    expiration_date: str = None
    registrar: str = None
    dns_provider: str = None
    status: str = None
    ssl_status: str = None
    mx_records: Optional[str] = None
    a_records: Optional[str] = None
    cname_records: Optional[str] = None

class DomainInDB(DomainBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class DomainResponse(DomainInDB):
    pass

class DomainList(BaseModel):
    items: List[DomainResponse]
    total: int
    page: int
    per_page: int
