from app.models.user import User  # noqa
from app.models.domain import Domain  # noqa