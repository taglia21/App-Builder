"""Domain schemas."""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime
from uuid import UUID

class DomainBase(BaseModel):
    name: str
    registrant: str
    expiration_date: datetime.date
    dns_provider: str = None
    registrar: str
    status: str = None
    nameservers: Optional[str] = None

class DomainCreate(DomainBase):
    pass

class DomainUpdate(BaseModel):
    name: str = None
    registrant: str = None
    expiration_date: datetime.date = None
    dns_provider: str = None
    registrar: str = None
    status: str = None
    nameservers: Optional[str] = None

class DomainInDB(DomainBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class DomainResponse(DomainInDB):
    pass

class DomainList(BaseModel):
    items: List[DomainResponse]
    total: int
    page: int
    per_page: int
