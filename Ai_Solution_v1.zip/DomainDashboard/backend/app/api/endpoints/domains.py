"""Domain CRUD endpoints."""

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List
from uuid import UUID

from app.db.session import get_db
from app.models.user import User
from app.models.domain import Domain
from app.schemas.domain import (
    DomainCreate, 
    DomainUpdate, 
    DomainResponse,
    DomainList
)
from app.crud.domain import crud_domain
from app.core.auth import get_current_user

router = APIRouter()

@router.get("/", response_model=DomainList)
async def list_domains(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List all domains for current user."""
    skip = (page - 1) * per_page
    items = crud_domain.get_multi(db, skip=skip, limit=per_page, user_id=current_user.id)
    total = crud_domain.count(db, user_id=current_user.id)
    
    return DomainList(
        items=items,
        total=total,
        page=page,
        per_page=per_page
    )

@router.post("/", response_model=DomainResponse, status_code=status.HTTP_201_CREATED)
async def create_domain(
    obj_in: DomainCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a new domain."""
    return crud_domain.create(db, obj_in=obj_in, user_id=current_user.id)

@router.get("/{id}", response_model=DomainResponse)
async def get_domain(
    id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific domain."""
    obj = crud_domain.get_by_user(db, id=id, user_id=current_user.id)
    if not obj:
        raise HTTPException(status_code=404, detail="Domain not found")
    return obj

@router.put("/{id}", response_model=DomainResponse)
async def update_domain(
    id: UUID,
    obj_in: DomainUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update a domain."""
    obj = crud_domain.get_by_user(db, id=id, user_id=current_user.id)
    if not obj:
        raise HTTPException(status_code=404, detail="Domain not found")
    return crud_domain.update(db, db_obj=obj, obj_in=obj_in)

@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_domain(
    id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Delete a domain."""
    obj = crud_domain.get_by_user(db, id=id, user_id=current_user.id)
    if not obj:
        raise HTTPException(status_code=404, detail="Domain not found")
    crud_domain.delete(db, id=id)
