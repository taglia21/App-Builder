export default function RegisterPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="p-8 text-center bg-white shadow-lg rounded-lg">
        <h1 className="text-2xl font-bold mb-4">Register</h1>
        <p className="mb-4">Implementation coming soon.</p>
        <a href="/" className="text-blue-500 hover:underline">Back to Home</a>
      </div>
    </div>
  );
}
