"""CRUD operations for AiModel."""

from app.crud.base import CRUDBase
from app.models.aimodel import AiModel
from app.schemas.aimodel import AiModelCreate, AiModelUpdate


class CRUDAiModel(CRUDBase[AiModel, AiModelCreate, AiModelUpdate]):
    pass

crud_aimodel = CRUDAiModel(AiModel)
