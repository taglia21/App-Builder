"""CRUD operations for Solution."""

from app.crud.base import CRUDBase
from app.models.solution import Solution
from app.schemas.solution import SolutionCreate, SolutionUpdate


class CRUDSolution(CRUDBase[Solution, SolutionCreate, SolutionUpdate]):
    pass

crud_solution = CRUDSolution(Solution)
