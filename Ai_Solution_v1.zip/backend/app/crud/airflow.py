"""CRUD operations for Airflow."""

from app.crud.base import CRUDBase
from app.models.airflow import Airflow
from app.schemas.airflow import AirflowCreate, AirflowUpdate


class CRUDAirflow(CRUDBase[Airflow, AirflowCreate, AirflowUpdate]):
    pass

crud_airflow = CRUDAirflow(Airflow)
