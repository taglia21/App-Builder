"""Solution schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class SolutionBase(BaseModel):
    name: str
    description: Optional[str] = None
    ai_model: str
    input_type: str
    output_type: str
    status: str = None

class SolutionCreate(SolutionBase):
    pass

class SolutionUpdate(BaseModel):
    name: str = None
    description: Optional[str] = None
    ai_model: str = None
    input_type: str = None
    output_type: str = None
    status: str = None

class SolutionInDB(SolutionBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class SolutionResponse(SolutionInDB):
    pass

class SolutionList(BaseModel):
    items: List[SolutionResponse]
    total: int
    page: int
    per_page: int
