"""Item schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class ItemBase(BaseModel):
    name: str
    description: Optional[str] = None
    status: str = None
    data: Optional[Dict] = None

class ItemCreate(ItemBase):
    pass

class ItemUpdate(BaseModel):
    name: str = None
    description: Optional[str] = None
    status: str = None
    data: Optional[Dict] = None

class ItemInDB(ItemBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class ItemResponse(ItemInDB):
    pass

class ItemList(BaseModel):
    items: List[ItemResponse]
    total: int
    page: int
    per_page: int
