"""Airflow schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class AirflowBase(BaseModel):
    sensor_type: str
    airflow_rate: float
    duct_size: str = None
    fan_speed: int = None
    filter_type: str = None
    installation_date: Optional[str] = None

class AirflowCreate(AirflowBase):
    pass

class AirflowUpdate(BaseModel):
    sensor_type: str = None
    airflow_rate: float = None
    duct_size: str = None
    fan_speed: int = None
    filter_type: str = None
    installation_date: Optional[str] = None

class AirflowInDB(AirflowBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class AirflowResponse(AirflowInDB):
    pass

class AirflowList(BaseModel):
    items: List[AirflowResponse]
    total: int
    page: int
    per_page: int
