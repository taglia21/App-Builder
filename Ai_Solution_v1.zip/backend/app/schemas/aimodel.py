"""AiModel schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class AiModelBase(BaseModel):
    name: str
    description: Optional[str] = None
    status: str = None
    model_type: str
    accuracy: float
    is_active: bool
    input_params: Optional[str] = None
    output_params: Optional[str] = None

class AiModelCreate(AiModelBase):
    pass

class AiModelUpdate(BaseModel):
    name: str = None
    description: Optional[str] = None
    status: str = None
    model_type: str = None
    accuracy: float = None
    is_active: bool = None
    input_params: Optional[str] = None
    output_params: Optional[str] = None

class AiModelInDB(AiModelBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class AiModelResponse(AiModelInDB):
    pass

class AiModelList(BaseModel):
    items: List[AiModelResponse]
    total: int
    page: int
    per_page: int
