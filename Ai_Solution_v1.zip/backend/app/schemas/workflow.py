"""Workflow schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class WorkflowBase(BaseModel):
    name: str
    description: Optional[str] = None
    is_active: bool = None
    config: Optional[Dict] = None

class WorkflowCreate(WorkflowBase):
    pass

class WorkflowUpdate(BaseModel):
    name: str = None
    description: Optional[str] = None
    is_active: bool = None
    config: Optional[Dict] = None

class WorkflowInDB(WorkflowBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class WorkflowResponse(WorkflowInDB):
    pass

class WorkflowList(BaseModel):
    items: List[WorkflowResponse]
    total: int
    page: int
    per_page: int
