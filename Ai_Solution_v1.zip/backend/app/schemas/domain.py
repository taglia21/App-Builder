"""Domain schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class DomainBase(BaseModel):
    domain_name: str
    registrar: str
    expiration_date: date
    lock_status: str = None
    owner_id: int
    dns_provider: str = None
    ssl_status: str = None

class DomainCreate(DomainBase):
    pass

class DomainUpdate(BaseModel):
    domain_name: str = None
    registrar: str = None
    expiration_date: date = None
    lock_status: str = None
    owner_id: int = None
    dns_provider: str = None
    ssl_status: str = None

class DomainInDB(DomainBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class DomainResponse(DomainInDB):
    pass

class DomainList(BaseModel):
    items: List[DomainResponse]
    total: int
    page: int
    per_page: int
