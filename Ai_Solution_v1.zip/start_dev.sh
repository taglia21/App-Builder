#!/bin/bash
echo "🚀 Starting AiSolution..."

# Check for Docker
if ! command -v docker &> /dev/null; then
    echo "Error: Docker is not installed."
    exit 1
fi

echo "Building and starting containers..."
docker-compose up --build
