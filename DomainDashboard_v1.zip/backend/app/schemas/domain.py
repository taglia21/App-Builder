"""Domain schemas."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID

from pydantic import BaseModel, Field


class DomainBase(BaseModel):
    name: str
    description: Optional[str] = None
    status: str = None
    expiration_date: Optional[date] = None
    registration_date: Optional[date] = None
    dns_provider: str = None
    domain_type: str = None

class DomainCreate(DomainBase):
    pass

class DomainUpdate(BaseModel):
    name: str = None
    description: Optional[str] = None
    status: str = None
    expiration_date: Optional[date] = None
    registration_date: Optional[date] = None
    dns_provider: str = None
    domain_type: str = None

class DomainInDB(DomainBase):
    id: UUID
    user_id: UUID
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

class DomainResponse(DomainInDB):
    pass

class DomainList(BaseModel):
    items: List[DomainResponse]
    total: int
    page: int
    per_page: int
