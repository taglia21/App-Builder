export const metadata = {
  title: "DomainDashboard",
  description: "Use AI to provide insights and recommendations for domain management",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
